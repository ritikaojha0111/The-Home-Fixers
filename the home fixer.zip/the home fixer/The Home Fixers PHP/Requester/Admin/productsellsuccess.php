<?php
session_start();
define('TITLE', 'Success');
//include('includes/header.php'); 
include('../dbConnection.php');

//include('../dbConnection.php');

// Debug statement
//echo "Start of script<br>";

if (isset($_SESSION['is_adminlogin'])) {
    $aEmail = $_SESSION['aEmail'];
    //echo "Admin is logged in as: $aEmail<br>"; // Debug statement
} else {
    //echo "<script> location.href='login.php'; </script>";
    exit;
}

if (isset($_SESSION['myid'])) {
    $myid = $_SESSION['myid'];
    //echo "Customer ID: $myid<br>"; // Debug statement
    
    $sql = "SELECT * FROM customer_tb WHERE custid = ?";
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        die('Prepare failed: ' . htmlspecialchars($conn->error));
    }

    $stmt->bind_param("i", $myid);

    if (!$stmt->execute()) {
        die('Execute failed: ' . htmlspecialchars($stmt->error));
    }

    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        echo "<div class='ml-5 mt-5'>
            <style>
            .text-center {
            text-align: center;
                }
                </style>

                <h3 class='text-center'>Customer Bill</h3>
                <table class='table'>
            <body>
            <style>
             .table-container {
             position: absolute;
                 bottom: 0;
                 width: 100%; /* Ensures the table spans the full width of the page */
                 text-align: center; /* Centers the table horizontally */
                     }
                 table {
                 margin: 0 auto; /* Centers the table */
                    border: 1px solid black; /* Adds border to the table */
                 border-collapse: collapse;
                         }
                     th, td {
                       border: 1px solid black;
                      padding: 10px;
                         }
                        </style>
                <tr>
                    <th>Customer ID</th>
                    <td>".$row['custid']."</td>
                </tr>
                <tr>
                    <th>Customer Name</th>
                    <td>".$row['custname']."</td>
                </tr>
                <tr>
                    <th>Address</th>
                    <td>".$row['custadd']."</td>
                </tr>
                <tr>
                    <th>Product</th>
                    <td>".$row['cpname']."</td>
                </tr>
                <tr>
                    <th>Quantity</th>
                    <td>".$row['cpquantity']."</td>
                </tr>
                <tr>
                    <th>Price Each</th>
                    <td>".$row['cpeach']."</td>
                </tr>
                <tr>
                    <th>Total Cost</th>
                    <td>".$row['cptotal']."</td>
                </tr>
                <tr>
                    <th>Date</th>
                    <td>".$row['cpdate']."</td>
                </tr>
                <tr>
                    <style>
                    .d-print-none {
                    text-align: center;
                     margin-top: 20px; /* Adds space between table and buttons */
                        }
                        </style>
                    <td><form class='d-print-none'><input class='btn btn-danger' type='submit' value='Print' onClick='window.print()'></form></td>
                    <td><a href='assets.php' class='btn btn-secondary d-print-none'>Close</a></td>
                </tr>
            </tbody>
        </table> 
        </div>";
    } else {
        echo "Failed to retrieve customer data";
    }

    $stmt->close();
} else {
    echo "Customer ID not set.";
}

$conn->close();
//include('../footer.php'); 

//echo "End of script<br>"; // Debug statement
?>